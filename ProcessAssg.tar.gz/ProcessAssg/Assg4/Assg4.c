#include"header.h"

/*
	4. Write a program which creates two processess as process2 and process3 and our parent process
	   terminates till both the processess terminates.
*/

int main(int argc,char *argv[])
{
	int cpid2,cpid3,pid;	
	pid=getpid();

	if(fork()==0)
	{

		cpid2=getpid();
		printf("\n Child process 2 \tpid = %d ",cpid2);
		printf("\t Parent of Child process 2 = %d \n",getppid());

	}
	else if(fork()==0)
	{
		
		cpid3=getpid();
		printf("\n Child process 3 \tpid = %d ",cpid3);
		printf("\t Parent of Child process 3 = %d \n",getppid());
		
	}
	else	
	{
		printf("\n Parent process \tpid = %d \n",pid);
		exit(0);
	}


}
