#include<stdio.h>
#include<unistd.h>

/*
	3. Write a program which creates three diffrent processess internally as process2, process3, process4.
*/


int main(int argc,char *argv[])
{
	int pid,cpid2,cpid3,cpid4;

	if(fork()==0)
	{
		cpid2=getpid();
		printf("\n Child process 2 \tpid = %d \n",cpid2);
	}
	else if(fork()==0)
	{
		cpid3=getpid();
		printf("\n Child process 3 \tpid = %d \n",cpid3);
	}
	else if(fork()==0)
	{
		cpid4=getpid();
		printf("\n Child process 4 \tpid = %d \n",cpid4);
	}
	else
	{
		pid=getpid();
		printf("\n Parent process : pid = %d \n",pid);
	}

	return 0;
}
	
	
	

