#include"header.h"
/*
	6. Write a program which creates new process which is responsible to write all file names which are
	   present on desktop in demo file which should be created newly.
*/

int main(int argc,char *argv[])
{
	DIR *dir;
	struct dirent *entry;
	
	int fd;

	if(argc!=2)
	{
		printf(" Invalid input argument..\n\n");
		return -1;
	} 

	if(fork()==0)
	{
		dir=opendir("/home/tejas/Desktop/");
		if(dir==NULL)
		{
			printf(" Cannot open directory \n");
			return -1;
		}
		
		fd=creat(argv[1],0666);
		if(fd==-1)
		{
			printf("file not created \n");	
			return -1;
		}

		while((entry=readdir(dir))!=NULL)
		{
			if(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)
			{
				continue;
			}
			write(fd,entry->d_name,strlen(entry->d_name));
			write(fd,"\n",1);		
		}
	}

	return 0;
}











			
