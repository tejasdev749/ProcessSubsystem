#include"header.h"

/*
	5. Write a program which is used to create deamon process.
*/

int main(int argc,char *argv[])
{
	
	printf("parent pid \t %d",getpid());	
	int ret;
	if(fork()==0)
	{
		ret=daemon(0,0);
		if(ret==-1)
		{
			printf("failed to create daemon process \n");
			return;
		}
	}	

	sleep(555);
	
	return 0;

}
