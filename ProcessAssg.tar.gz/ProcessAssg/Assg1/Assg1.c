#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>

/*

	1. Write a program in which parent process waits till its child process terminates.

*/

int main(int argc,char *argv[])
{
	printf("\n Parent says Hello \n");
	if(fork()==0)
	{
		printf("\n Child says Hi \n");
	}
	else
	{
		wait(NULL);
		printf("\n Parent waits for child to terminate and then says World \n");
	}

	return 0;
}

