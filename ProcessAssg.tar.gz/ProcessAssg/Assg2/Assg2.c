#include<stdio.h>
#include<unistd.h>

/*
	2. Write a program which create three level process hierarchy where process 1 creates process 2 and it
	internally creates process 
*/

int main(int argc,char *argv[])
{

	if(fork()==0)
	{	
		if(fork()==0)
		{
			printf("\n I am process 3 child of Process 2 \n");
		}
		else
		{
			printf("\n I am process 2 child of Process 1 \n");
		}
	}
	else
	{
		printf("\n I am process 1 \n");
	}
	
	return 0;
}
	
	 

