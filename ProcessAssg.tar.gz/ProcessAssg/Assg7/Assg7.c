#include"header.h"
/*
	7.Write a program which creates two processess.
          Process 1 count number of capital characters from demo.txt file.
	  And process 2 count number of capital characters from hello.txt file.
	  Both the processess writes its count in count.txt file.
*/

int main(int argc,char *argv[])
{
	int fd,fd2,ret1,ret2,iCnt1=0,iCnt2=0;
	char str[256]={'\0'};
	char Brr[256]={'\0'};
	FILE *fp=NULL;
	char c='\n';	
	
	if(argc!=4)
	{
		printf(" Invalid input argument ..\n\n");	
		return -1;
	}
	
	if(fork()==0)
	{
//		printf(" Inside process 1 \n\n");
		
		fd=open(argv[1],O_RDONLY);
		if(fd==-1)	
		{
			printf("%s file could not be opened .. \n",argv[1]);
			return -1;
		}
		
		while((ret1=read(fd,str,sizeof(str)))!=0)
		{
			ret1--;
			while(ret1>=0)
			{
				if((str[ret1]>='A') && (str[ret1] <='Z'))
				{
					iCnt1++;
				}
				ret1--;
			}
			memset(str,0,sizeof(str));
		}	
		
	
		fp=fopen(argv[3],"w");
		if(fp==NULL)
		{
			printf(" Unable to open file ");
			return -1;
		}
		
		fprintf(fp,"%d",iCnt1);
		
//		printf(" capital letters in demo %d\n",iCnt1);

		fclose(fp);
		close(fd);

	}
	else if(fork()==0)
	{
//		printf(" Inside process 2 \n\n");

		fd2=open(argv[2],O_RDONLY);
		if(fd2==-1)
		{
			printf("%s file could not be opened .. \n",argv[2]);
			return -1;
		}	

		while((ret2=read(fd2,Brr,sizeof(Brr)))!=0)
		{
			ret2--;
			while(ret2>=0)
			{
				if((Brr[ret2]>='A') && (Brr[ret2]<='Z'))
				{
					 iCnt2++;
				}
				ret2--;
			}
			memset(Brr,0,sizeof(Brr));
		}			

//		printf(" capital letters in hello %d\n",iCnt2);
		fp=fopen(argv[3],"w");
		if(fp==NULL)
		{
			printf(" Unable to open file ");
			return -1;
		}
		fprintf(fp,"%c",c);		
		fprintf(fp,"%d",iCnt2);
	}
	
	return 0;
}






